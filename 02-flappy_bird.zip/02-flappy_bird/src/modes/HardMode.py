from .FlappyModes import FlappyGameMode
from gale.input_handler import InputData
from src.LogPair import LogPair

import settings
import random

class HardMode(FlappyGameMode):
    def __init__(self):
        self.timer_to_spawn_logs = 1.5
        self.ghost_spawn_timer = 0.0
        self.ghost_timer = random.uniform(5.0, 20.0)

    def update_world(self, world, dt) -> None:
        world.generate_logs = False

        world.logs_spawn_timer += dt
        self.ghost_spawn_timer += dt

        if world.logs_spawn_timer >= self.timer_to_spawn_logs:
            is_going_to_move = random.random() <= 0.40
            if is_going_to_move:
                gap = random.randint(110, 130)
                self.timer_to_spawn_logs = random.uniform(1.8, 2.4)
                value = 45
            else:
                number = random.random()

                if number <= 0.30:
                    gap = random.randint(80, 90)
                    value = 50
                    self.timer_to_spawn_logs = random.uniform(1.8, 2.4)
                elif number <= 0.70:
                    value = 40
                    gap = random.randint(80, 100)
                    self.timer_to_spawn_logs = random.uniform(1.4, 1.8)
                else:
                    value = 30
                    gap = random.randint(100, 120)
                    self.timer_to_spawn_logs = random.uniform(1.0, 1.6)
            
            world.logs_spawn_timer = 0.0
            y = max(
                -settings.LOG_HEIGHT + 20,
                min(
                    world.last_log_y + random.randint(-value, value),
                    settings.VIRTUAL_HEIGHT - gap - settings.LOG_HEIGHT - 20 -settings.GROUND_HEIGHT,
                ),
            )
            world.last_log_y = y

            log_pair : LogPair = world.log_pair_factory.create(settings.VIRTUAL_WIDTH, y)
            log_pair.gap = gap
            log_pair.original_gap = gap
            log_pair.move = is_going_to_move
            world.logs.append(log_pair)

        if self.ghost_spawn_timer >= self.ghost_timer:
            if world.logs:
                last_log = world.logs[-1]
                gap_center = last_log.y + settings.LOG_HEIGHT + (last_log.gap / 2)
                ghost_y = int(gap_center - (settings.GHOST_HEIGHT/2))
            else:
                ghost_y = settings.VIRTUAL_HEIGHT / 2

            world.spawn_ghost(settings.VIRTUAL_WIDTH + settings.GHOST_WIDTH, ghost_y)
            self.ghost_timer = random.uniform(5.0, 20.0)
            self.ghost_spawn_timer = 0.0
        
    def on_input(self, bird, input_id: str, input_data: InputData) -> None:
        if input_id == "jump" and input_data.pressed:
            bird.jump()
        elif input_id == "left":
            if input_data.pressed:
                bird.vx = -200
            else:
                bird.vx = 0
        elif input_id == "right":
            if input_data.pressed:
                bird.vx = 200
            else:
                bird.vx = 0